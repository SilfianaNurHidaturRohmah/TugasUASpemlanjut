
<div class="container">
    <h1>Tambah Barang</h1>
    <form action="<?php echo e(route('barangs.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nama">Nama</label>
            <input type="text" id="nama" name="nama">
        </div>
        <div>
            <label for="stok">Stok</label>
            <input type="text" id="stok" name="stok">
        </div>
        <div>
            <label for="harga">Harga</label>
            <input type="text" id="harga" name="harga">
        </div>
        <div>
            <label for="jumlah_barang">Jumlah Barang</label>
            <input type="text" id="jumlah_barang" name="jumlah_barang">
        </div>
        <button type="submit">Simpan</button>
    </form>
</div>

<?php /**PATH C:\Users\ACER\OneDrive\Documents\inventaris2\resources\views/barangs/create.blade.php ENDPATH**/ ?>