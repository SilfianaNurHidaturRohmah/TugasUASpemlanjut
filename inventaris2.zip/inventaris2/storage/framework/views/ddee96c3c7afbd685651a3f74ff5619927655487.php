
<div class="container">
    <h1>Tambah Pesanan</h1>
    <form action="<?php echo e(route('pesanans.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nama_pelanggan">Nama Pelanggan</label>
            <input type="text" id="nama_pelanggan" name="nama_pelanggan">
        </div>
        <div>
            <label for="tanggal_pesanan">Tanggal Pesanan</label>
            <input type="date" id="tanggal_pesanan" name="tanggal_pesanan">
        </div>
        <div>
            <label for="total_harga">Total Harga</label>
            <input type="text" id="total_harga" name="total_harga">
        </div>
        <div>
            <label for="jumlah_barang">Jumlah Barang</label>
            <input type="text" id="jumlah_barang" name="jumlah_barang">
        </div>
        <button type="submit">Simpan</button>
    </form>
</div>

<?php /**PATH C:\Users\ACER\OneDrive\Documents\inventaris2\resources\views/pesanans/create.blade.php ENDPATH**/ ?>