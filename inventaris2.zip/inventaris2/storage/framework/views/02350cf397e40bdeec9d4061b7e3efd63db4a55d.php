
<div class="container">
    <h1>Daftar Pesanan</h1>
    <a href="<?php echo e(route('pesanans.create')); ?>">Tambah Pesanan</a>
    <table>
        <thead>
            <tr>
                <th>Nama Pelanggan</th>
                <th>Tanggal Pesanan</th>
                <th>Total Harga</th>
                <th>Jumlah Barang</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pesanan->nama_pelanggan); ?></td>
                    <td><?php echo e($pesanan->tanggal_pesanan); ?></td>
                    <td><?php echo e($pesanan->total_harga); ?></td>
                    <td><?php echo e($pesanan->jumlah_barang); ?></td>
                    <td>
                        <a href="<?php echo e(route('pesanans.edit', $pesanan->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('pesanans.destroy', $pesanan->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH C:\Users\ACER\OneDrive\Documents\inventaris2\resources\views/pesanans/index.blade.php ENDPATH**/ ?>