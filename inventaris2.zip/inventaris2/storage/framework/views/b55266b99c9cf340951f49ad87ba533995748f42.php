
<div class="container">
    <h1>Daftar Barang</h1>
    <a href="<?php echo e(route('barangs.create')); ?>">Tambah Barang</a>
    <table>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Jumlah Barang</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($barang->nama); ?></td>
                    <td><?php echo e($barang->stok); ?></td>
                    <td><?php echo e($barang->harga); ?></td>
                    <td><?php echo e($barang->jumlah_barang); ?></td>
                    <td>
                        <a href="<?php echo e(route('barangs.edit', $barang->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('barangs.destroy', $barang->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH C:\Users\ACER\OneDrive\Documents\inventaris2\resources\views/barangs/index.blade.php ENDPATH**/ ?>