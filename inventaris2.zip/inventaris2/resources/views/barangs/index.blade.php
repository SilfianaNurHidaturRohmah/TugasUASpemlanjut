
<div class="container">
    <h1>Daftar Barang</h1>
    <a href="{{ route('barangs.create') }}">Tambah Barang</a>
    <table>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Jumlah Barang</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($barangs as $barang)
                <tr>
                    <td>{{ $barang->nama }}</td>
                    <td>{{ $barang->stok }}</td>
                    <td>{{ $barang->harga }}</td>
                    <td>{{ $barang->jumlah_barang }}</td>
                    <td>
                        <a href="{{ route('barangs.edit', $barang->id) }}">Edit</a>
                        <form action="{{ route('barangs.destroy', $barang->id) }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

