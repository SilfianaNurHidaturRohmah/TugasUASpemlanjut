
<div class="container">
    <h1>Edit Barang</h1>
    <form action="{{ route('barangs.update', $barang->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <label for="nama">Nama</label>
            <input type="text" id="nama" name="nama" value="{{ $barang->nama }}">
        </div>
        <div>
            <label for="stok">Stok</label>
            <input type="text" id="stok" name="stok" value="{{ $barang->stok }}">
        </div>
        <div>
            <label for="harga">Harga</label>
            <input type="text" id="harga" name="harga" value="{{ $barang->harga }}">
        </div>
        <div>
            <label for="jumlah_barang">Jumlah Barang</label>
            <input type="text" id="jumlah_barang" name="jumlah_barang" value="{{ $barang->jumlah_barang }}">
        </div>
        <button type="submit">Perbarui</button>
    </form>
</div>

