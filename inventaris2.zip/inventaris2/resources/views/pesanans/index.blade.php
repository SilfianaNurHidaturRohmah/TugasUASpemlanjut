
<div class="container">
    <h1>Daftar Pesanan</h1>
    <a href="{{ route('pesanans.create') }}">Tambah Pesanan</a>
    <table>
        <thead>
            <tr>
                <th>Nama Pelanggan</th>
                <th>Tanggal Pesanan</th>
                <th>Total Harga</th>
                <th>Jumlah Barang</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($pesanans as $pesanan)
                <tr>
                    <td>{{ $pesanan->nama_pelanggan }}</td>
                    <td>{{ $pesanan->tanggal_pesanan }}</td>
                    <td>{{ $pesanan->total_harga }}</td>
                    <td>{{ $pesanan->jumlah_barang }}</td>
                    <td>
                        <a href="{{ route('pesanans.edit', $pesanan->id) }}">Edit</a>
                        <form action="{{ route('pesanans.destroy', $pesanan->id) }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

