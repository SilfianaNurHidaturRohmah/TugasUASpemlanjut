
<div class="container">
    <h1>Edit Pesanan</h1>
    <form action="{{ route('pesanans.update', $pesanan->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <label for="nama_pelanggan">Nama Pelanggan</label>
            <input type="text" id="nama_pelanggan" name="nama_pelanggan" value="{{ $pesanan->nama_pelanggan }}">
        </div>
        <div>
            <label for="tanggal_pesanan">Tanggal Pesanan</label>
            <input type="date" id="tanggal_pesanan" name="tanggal_pesanan" value="{{ $pesanan->tanggal_pesanan }}">
        </div>
        <div>
            <label for="total_harga">Total Harga</label>
            <input type="text" id="total_harga" name="total_harga" value="{{ $pesanan->total_harga }}">
        </div>
        <div>
            <label for="jumlah_barang">Jumlah Barang</label>
            <input type="text" id="jumlah_barang" name="jumlah_barang" value="{{ $pesanan->jumlah_barang }}">
        </div>
        <button type="submit">Perbarui</button>
    </form>
</div>

