<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pesanan;

class PesananController extends Controller
{
    public function index()
    {
        $pesanans = Pesanan::all();
        return view('pesanans.index', compact('pesanans'));
    }

    public function create()
    {
        return view('pesanans.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_pelanggan' => 'required',
            'tanggal_pesanan' => 'required|date',
            'total_harga' => 'required|numeric',
            'jumlah_barang' => 'required|integer',
        ]);

        Pesanan::create($request->all());

        return redirect()->route('pesanans.index')
                        ->with('success', 'Pesanan berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $pesanan = Pesanan::find($id);
        return view('pesanans.edit', compact('pesanan'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_pelanggan' => 'required',
            'tanggal_pesanan' => 'required|date',
            'total_harga' => 'required|numeric',
            'jumlah_barang' => 'required|integer',
        ]);

        $pesanan = Pesanan::find($id);
        $pesanan->update($request->all());

        return redirect()->route('pesanans.index')
                        ->with('success', 'Pesanan berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $pesanan = Pesanan::find($id);
        $pesanan->delete();

        return redirect()->route('pesanans.index')
                        ->with('success', 'Pesanan berhasil dihapus.');
    }
    
}
