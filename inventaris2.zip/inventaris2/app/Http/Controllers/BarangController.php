<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use Illuminate\Http\Request;

class BarangController extends Controller
{
    public function index()
    {
        $barangs = Barang::all();
        return view('barangs.index', compact('barangs'));
    }

    public function create()
    {
        return view('barangs.create');
    }

    public function store(Request $request)
    {
        Barang::create($request->all());
        return redirect()->route('barangs.index');
    }

    public function edit(Barang $barang)
    {
        return view('barangs.edit', compact('barang'));
    }

    public function update(Request $request, Barang $barang)
    {
        $barang->update($request->all());
        return redirect()->route('barangs.index');
    }

    public function destroy(Barang $barang)
    {
        $barang->delete();
        return redirect()->route('barangs.index');
    }

    public function increaseStock(Barang $barang)
    {
        $barang->stok += 1;
        $barang->save();
        return redirect()->route('barangs.index');
    }

    public function decreaseStock(Barang $barang)
    {
        if ($barang->stok > 0) {
            $barang->stok -= 1;
            $barang->save();
        }
        return redirect()->route('barangs.index');
    }
}
